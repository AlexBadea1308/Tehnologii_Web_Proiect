import React from 'react';
import { Routes, Route } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import HomePage from './pages/HomePage';
import AccountPage from './pages/AccountPage';
import EditProfilePage from './pages/EditProfile';
import ForgotPasswordPage from './pages/ForgotPassword';
import AboutPage from './pages/AboutPage';
import ShopPage from './pages/ShopPage';
import CartPage from './pages/CartPage';
import PaymentPage from './pages/PaymentPage';
import TicketPage from './pages/TicketPage';
import FixturesPage from './pages/FixturesPage';
import ContactPage from './pages/ContactPage';
import OrdersHistoryPage from './pages/OrderHistory';
import ManagerHomePage from './pages/ManagerHomePage';
import AdminHomePage from './pages/AdminHomePage';
import PlayerHomePage from './pages/PlayerHomePage';

function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/shop" element={<ShopPage />} />
        <Route path="/cart" element={<CartPage />} />
        <Route path="/tickets" element={<TicketPage />} />
        <Route path="/fixtures" element={<FixturesPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/forgot-password" element={<ForgotPasswordPage />} />
        <Route path="/account" element={<AccountPage />} />
        <Route path="/edit-profile" element={<EditProfilePage />} />
        <Route path="/orders-history" element={<OrdersHistoryPage />} />
        <Route path="/payment" element={<PaymentPage />} />
        <Route path="/player-home" element={<PlayerHomePage />} />
        <Route path="/manager-home" element={<ManagerHomePage />} />
        <Route path="/admin-home" element={<AdminHomePage />} />
      </Routes>
    </>
  );
}

export default App;