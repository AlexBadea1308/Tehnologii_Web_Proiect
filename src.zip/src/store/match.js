import { create } from 'zustand';

export const useMatchStore = create((set) => ({
  matches: [],
  loading: false,
  error: null,
  fetchMatches: async () => {
    set({ loading: true, error: null });
    try {
      const response = await fetch('/api/matches');
      const data = await response.json();
      if (!data.success) {
        throw new Error(data.message || 'Failed to fetch matches');
      }
      set({ matches: data.data, loading: false });
    } catch (error) {
      set({ error: error.message, loading: false });
    }
  },
}));