import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import axios from 'axios';
import { useAuthStore } from './authStore';

export const useCartStore = create(
  persist(
    (set, get) => ({
      cart: [],
      shippingMethod: null,
      paymentMethod: null,

      addToCart: async (item) => {
        const cart = get().cart;
        const user = useAuthStore.getState().user;
        const storageKey = user ? `cart-${user._id}` : null;

        const existingItem = cart.find(
          (i) =>
            i._id === item._id &&
            i.productType === item.productType &&
            (item.productType === 'ticket' ? i.seatCategory === item.seatCategory : true)
        );
        const quantityToAdd = item.quantity || 1;
        const currentQuantity = existingItem ? existingItem.quantity : 0;
        const newQuantity = currentQuantity + quantityToAdd;

        if (item.productType === 'ticket') {
          try {
            const response = await axios.get(`/api/tickets/${item.matchId}/${item.seatCategory}`);
            const ticket = response.data.data;
            if (!ticket) throw new Error('Ticket not found');

            const ticketsForMatch = cart
              .filter((i) => i.productType === 'ticket' && i.matchId === item.matchId)
              .reduce((sum, i) => sum + i.quantity, 0);

            const remainingForMatch = 5 - ticketsForMatch;
            const remainingForCategory = ticket.availableTickets - currentQuantity;

            if (quantityToAdd > remainingForMatch) {
              throw new Error(`Only ${remainingForMatch} more tickets allowed for this match (max 5)`);
            }
            if (newQuantity > ticket.availableTickets) {
              throw new Error(`Only ${ticket.availableTickets} tickets available for ${item.seatCategory}`);
            }
          } catch (error) {
            throw new Error(error.message || 'Error checking ticket availability');
          }
        } else if (item.productType === 'product') {
          try {
            const response = await axios.get(`/api/products/${item._id}`);
            const product = response.data.data;
            const productsInCart = cart
              .filter((i) => i.productType === 'product' && i._id === item._id)
              .reduce((sum, i) => sum + i.quantity, 0);

            const remainingForLimit = 10 - productsInCart;
            const remainingStock = product.stock - currentQuantity;

            if (quantityToAdd > remainingForLimit) {
              throw new Error(`Only ${remainingForLimit} more items allowed (max 10 per product)`);
            }
            if (newQuantity > product.stock) {
              throw new Error(`Only ${product.stock} items available`);
            }
          } catch (error) {
            throw new Error(error.message || 'Error checking product availability');
          }
        }

        if (existingItem) {
          set({
            cart: cart.map((cartItem) =>
              cartItem._id === existingItem._id &&
              cartItem.productType === existingItem.productType &&
              (cartItem.productType === 'ticket' ? cartItem.seatCategory === existingItem.seatCategory : true)
                ? { ...cartItem, quantity: newQuantity }
                : cartItem
            ),
          });
        } else {
          set({
            cart: [...cart, { ...item, quantity: quantityToAdd }],
          });
        }

        if (user) {
          localStorage.setItem(storageKey, JSON.stringify(get().cart));
        }
      },

      removeFromCart: (productId, productType, seatCategory = null) => {
        const user = useAuthStore.getState().user;
        const storageKey = user ? `cart-${user._id}` : null;

        set({
          cart: get().cart.filter(
            (item) =>
              !(
                item._id === productId &&
                item.productType === productType &&
                (productType === 'ticket' ? item.seatCategory === seatCategory : true)
              )
          ),
        });

        if (user) {
          localStorage.setItem(storageKey, JSON.stringify(get().cart));
        }
      },

      updateQuantity: async (productId, productType, seatCategory, quantity) => {
        if (quantity < 1) return;
        const cart = get().cart;
        const user = useAuthStore.getState().user;
        const storageKey = user ? `cart-${user._id}` : null;

        const item = cart.find(
          (i) =>
            i._id === productId &&
            i.productType === productType &&
            (productType === 'ticket' ? i.seatCategory === seatCategory : true)
        );
        if (!item) return;

        if (productType === 'ticket') {
          try {
            const response = await axios.get(`/api/tickets?matchId=${item.matchId}&seatCategory=${seatCategory}`);
            const ticket = response.data.data[0];
            if (!ticket) throw new Error('Ticket not found');

            const ticketsForMatch = cart
              .filter(
                (i) =>
                  i.productType === 'ticket' &&
                  i.matchId === item.matchId &&
                  !(i._id === productId && i.seatCategory === seatCategory)
              )
              .reduce((sum, i) => sum + i.quantity, 0);

            const maxForMatch = 5 - ticketsForMatch;
            const maxForCategory = ticket.availableTickets;

            if (quantity > maxForMatch) {
              throw new Error(`Only ${maxForMatch} more tickets allowed for this match (max 5)`);
            }
            if (quantity > maxForCategory) {
              throw new Error(`Only ${maxForCategory} tickets available for ${seatCategory}`);
            }
          } catch (error) {
            throw new Error(error.message || 'Error checking ticket availability');
          }
        } else if (productType === 'product') {
          try {
            const response = await axios.get(`/api/products/${productId}`);
            const product = response.data.data;
            const productsInCart = cart
              .filter((i) => i.productType === 'product' && i._id === productId && i._id !== productId)
              .reduce((sum, i) => sum + i.quantity, 0);

            const maxForLimit = 10 - productsInCart;
            const maxStock = product.stock;

            if (quantity > maxForLimit) {
              throw new Error(`Only ${maxForLimit} more items allowed (max 10 per product)`);
            }
            if (quantity > maxStock) {
              throw new Error(`Only ${maxStock} items available`);
            }
          } catch (error) {
            throw new Error(error.message || 'Error checking product availability');
          }
        }

        set({
          cart: cart.map((item) =>
            item._id === productId &&
            item.productType === productType &&
            (productType === 'ticket' ? item.seatCategory === seatCategory : true)
              ? { ...item, quantity }
              : item
          ),
        });

        if (user) {
          localStorage.setItem(storageKey, JSON.stringify(get().cart));
        }
      },

      loadUserCart: () => {
        const user = useAuthStore.getState().user;
        if (!user) {
          set({ cart: [] });
          return;
        }
        const storageKey = `cart-${user._id}`;
        const savedCart = JSON.parse(localStorage.getItem(storageKey)) || [];
        set({ cart: savedCart });
      },

      clearCartInMemory: () => {
        set({ cart: [] });
      },

      clearCart: () => {
        const user = useAuthStore.getState().user;
        const storageKey = user ? `cart-${user._id}` : null;
        set({ cart: [] });
        if (user) {
          localStorage.removeItem(storageKey);
        }
      },

      checkout: () => {
        const user = useAuthStore.getState().user;
        if (!user) {
          throw new Error('You must be logged in to proceed with checkout.');
        }
      },

      setShippingMethod: (method) => {
        const user = useAuthStore.getState().user;
        if (!user) return;
        const userId = user._id;
        set({ shippingMethod: method });
        localStorage.setItem(`shipping-${userId}`, method);
      },

      setPaymentMethod: (method) => {
        const user = useAuthStore.getState().user;
        if (!user) return;
        const userId = user._id;
        set({ paymentMethod: method });
        localStorage.setItem(`payment-${userId}`, method);
      },

      loadUserPreferences: () => {
        const user = useAuthStore.getState().user;
        if (!user) return;
        const userId = user._id;
        set({
          shippingMethod: localStorage.getItem(`shipping-${userId}`) || null,
          paymentMethod: localStorage.getItem(`payment-${userId}`) || null,
        });
      },

      getCartTotal: () => {
        return get().cart.reduce((total, item) => total + (item.price * item.quantity), 0);
      },

      getCartCount: () => {
        return get().cart.reduce((count, item) => count + item.quantity, 0);
      },
    }),
    {
      name: 'cart-storage',
      getStorage: () => localStorage,
    }
  )
);