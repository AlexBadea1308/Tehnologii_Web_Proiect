import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import axios from 'axios';

export const useCartStore = create(
  persist(
    (set, get) => ({
      cart: [],
      
      addToCart: async (item) => {
        const cart = get().cart;
        const existingItem = cart.find(
          (i) => i._id === item._id && 
                 i.productType === item.productType && 
                 (item.productType === 'ticket' ? i.seatCategory === item.seatCategory : true)
        );
        const quantityToAdd = item.quantity || 1;
        const currentQuantity = existingItem ? existingItem.quantity : 0;
        const newQuantity = currentQuantity + quantityToAdd;
      
        if (item.productType === 'ticket') {
          try {
            const response = await axios.get(`/api/tickets/${item.matchId}/${item.seatCategory}`);
            const ticket = response.data.data;
            if (!ticket) {
              throw new Error('Ticket not found');
            }
      
            const ticketsForMatch = cart.filter(
              (i) => i.productType === 'ticket' && i.matchId === item.matchId
            ).reduce((sum, i) => sum + i.quantity, 0);
      
            const remainingForMatch = 5 - ticketsForMatch;
            const remainingForCategory = ticket.availableTickets - currentQuantity;
      
            if (quantityToAdd > remainingForMatch) {
              throw new Error(`Only ${remainingForMatch} more tickets allowed for this match (max 5)`);
            }
            if (newQuantity > ticket.availableTickets) {
              throw new Error(`Only ${ticket.availableTickets} tickets available for ${item.seatCategory}`);
            }
          } catch (error) {
            throw new Error(error.message || 'Error checking ticket availability');
          }
        }
        // Verifică stocul și limita pentru produse
        else if (item.productType === 'product') {
          try {
            const response = await axios.get(`/api/products/${item._id}`);
            const product = response.data.data;
            const productsInCart = cart.filter(
              (i) => i.productType === 'product' && i._id === item._id
            ).reduce((sum, i) => sum + i.quantity, 0);

            const remainingForLimit = 10 - productsInCart;
            const remainingStock = product.stock - currentQuantity;

            if (quantityToAdd > remainingForLimit) {
              throw new Error(`Only ${remainingForLimit} more items allowed (max 10 per product)`);
            }
            if (newQuantity > product.stock) {
              throw new Error(`Only ${product.stock} items available`);
            }
          } catch (error) {
            throw new Error(error.message || 'Error checking product availability');
          }
        }

        if (existingItem) {
          set({
            cart: cart.map((cartItem) => 
              cartItem._id === existingItem._id && 
              cartItem.productType === existingItem.productType && 
              (cartItem.productType === 'ticket' ? cartItem.seatCategory === existingItem.seatCategory : true)
                ? { ...cartItem, quantity: newQuantity }
                : cartItem
            )
          });
        } else {
          set({
            cart: [...cart, { ...item, quantity: quantityToAdd }]
          });
        }
      },
      
      removeFromCart: (productId, productType, seatCategory = null) => {
        set({
          cart: get().cart.filter((item) => 
            !(item._id === productId && 
              item.productType === productType && 
              (productType === 'ticket' ? item.seatCategory === seatCategory : true))
          )
        });
      },
      
      updateQuantity: async (productId, productType, seatCategory, quantity) => {
        if (quantity < 1) return;
      
        const cart = get().cart;
        const item = cart.find(
          (i) => i._id === productId && 
                 i.productType === productType && 
                 (productType === 'ticket' ? i.seatCategory === seatCategory : true)
        );
        if (!item) return;
      
        // Verifică disponibilitatea pentru bilete
        if (productType === 'ticket') {
          try {
            const response = await axios.get(`/api/tickets?matchId=${item.matchId}&seatCategory=${seatCategory}`);
            const ticket = response.data.data[0];
            if (!ticket) {
              throw new Error('Ticket not found');
            }
      
            const ticketsForMatch = cart.filter(
              (i) => i.productType === 'ticket' && i.matchId === item.matchId &&
                !(i._id === productId && i.seatCategory === seatCategory)
            ).reduce((sum, i) => sum + i.quantity, 0);
      
            const maxForMatch = 5 - ticketsForMatch;
            const maxForCategory = ticket.availableTickets;
      
            if (quantity > maxForMatch) {
              throw new Error(`Only ${maxForMatch} more tickets allowed for this match (max 5)`);
            }
            if (quantity > maxForCategory) {
              throw new Error(`Only ${maxForCategory} tickets available for ${seatCategory}`);
            }
          } catch (error) {
            throw new Error(error.message || 'Error checking ticket availability');
          }
        } 
        // Verifică stocul și limita pentru produse
        else if (productType === 'product') {
          try {
            const response = await axios.get(`/api/products/${productId}`);
            const product = response.data.data;
            const productsInCart = cart.filter(
              (i) => i.productType === 'product' && i._id === productId &&
                i._id !== productId // Excludem item-ul curent pentru a calcula doar celelalte
            ).reduce((sum, i) => sum + i.quantity, 0);
      
            const maxForLimit = 10 - productsInCart;
            const maxStock = product.stock;
      
            if (quantity > maxForLimit) {
              throw new Error(`Only ${maxForLimit} more items allowed (max 10 per product)`);
            }
            if (quantity > maxStock) {
              throw new Error(`Only ${maxStock} items available`);
            }
          } catch (error) {
            throw new Error(error.message || 'Error checking product availability');
          }
        }
      
        set({
          cart: cart.map((item) => 
            item._id === productId && 
            item.productType === productType && 
            (productType === 'ticket' ? item.seatCategory === seatCategory : true)
              ? { ...item, quantity }
              : item
          )
        });
      },
      
      getCartTotal: () => {
        return get().cart.reduce((total, item) => total + (item.price * item.quantity), 0);
      },
      
      clearCart: () => {
        set({ cart: [] });
      },
      
      getCartCount: () => {
        return get().cart.reduce((count, item) => count + item.quantity, 0);
      }
    }),
    {
      name: 'cart-storage',
      getStorage: () => localStorage,
    }
  )
);