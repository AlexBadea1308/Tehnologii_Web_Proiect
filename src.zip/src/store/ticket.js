import { create } from 'zustand';
import axios from 'axios';

export const useTicketStore = create((set, get) => ({
  tickets: [],
  loading: false,
  error: null,

  fetchTickets: async () => {
    set({ loading: true, error: null });
    try {
      const response = await axios.get('/api/tickets');
      set({ 
        tickets: response.data.data, 
        loading: false 
      });
      return { success: true, data: response.data.data };
    } catch (error) {
      console.error('Ticket Fetch Error:', error);
      set({ 
        error: error.response?.data?.message || "Failed to fetch tickets", 
        loading: false 
      });
      return { success: false, message: error.response?.data?.message || error.message };
    }
  },

  getTicketById: async (id) => {
    set({ loading: true, error: null });
    try {
      const response = await axios.get(`/api/tickets/${id}`);
      console.log('Fetched Ticket by ID:', response.data.data);
      set({ loading: false });
      return { success: true, data: response.data.data };
    } catch (error) {
      console.error('Get Ticket by ID Error:', error);
      set({ 
        error: error.response?.data?.message || "Failed to fetch ticket", 
        loading: false 
      });
      return { success: false, message: error.response?.data?.message || error.message };
    }
  },

  createTicket: async (ticketData) => {
    set({ loading: true, error: null });
    try {
      const response = await axios.post('/api/tickets', ticketData);
      set({ 
        tickets: [...get().tickets, response.data.data],
        loading: false 
      });
      return { success: true, data: response.data.data };
    } catch (error) {
      set({ 
        error: error.response?.data?.message || "Failed to create ticket", 
        loading: false 
      });
      return { success: false, message: error.response?.data?.message || "Failed to create ticket" };
    }
  },

  updateTicket: async (id, ticketData) => {
    set({ loading: true, error: null });
    try {
      const response = await axios.put(`/api/tickets/${id}`, ticketData);
      set({ 
        tickets: get().tickets.map(ticket => 
          ticket._id === id ? response.data.data : ticket
        ),
        loading: false 
      });
      return { success: true, data: response.data.data };
    } catch (error) {
      set({ 
        error: error.response?.data?.message || "Failed to update ticket", 
        loading: false 
      });
      return { success: false, message: error.response?.data?.message || "Failed to update ticket" };
    }
  },

  deleteTicket: async (id) => {
    set({ loading: true, error: null });
    try {
      await axios.delete(`/api/tickets/${id}`);
      set({ 
        tickets: get().tickets.filter(ticket => ticket._id !== id),
        loading: false 
      });
      return { success: true, message: "Ticket successfully deleted" };
    } catch (error) {
      set({ 
        error: error.response?.data?.message || "Failed to delete ticket", 
        loading: false 
      });
      return { success: false, message: error.response?.data?.message || "Failed to delete ticket" };
    }
  }
}));