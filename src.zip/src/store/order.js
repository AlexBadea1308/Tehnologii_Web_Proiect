// src/store/order.js
import { create } from 'zustand';
import axios from 'axios';

const useOrderStore = create((set) => ({
  orders: [],
  loading: false,
  error: null,

  fetchOrders: async (userId) => {
    set({ loading: true, error: null });
    try {
      const response = await axios.get(`/api/orders/user/${userId}`);
      set({ orders: response.data.data, loading: false }); 
      return response.data.data;
    } catch (error) {
      set({ error: error.message || 'Failed to fetch orders', loading: false });
    }
  },
}));

export { useOrderStore };