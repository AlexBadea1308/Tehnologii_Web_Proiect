import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { useCartStore } from "./cart"; 

export const useAuthStore = create(
  persist(
    (set) => ({
      user: null,
      token: null,
      isAuthenticated: false,

      login: (userData, token) => {
        set({ 
          user: userData, 
          token: token, 
          isAuthenticated: true 
        });

        // Încărcăm coșul utilizatorului după autentificare
        useCartStore.getState().loadUserCart();
      },

      logout: () => {
        set({ 
          user: null, 
          token: null, 
          isAuthenticated: false 
        });

        // Ștergem coșul utilizatorului
        useCartStore.getState().clearCart();
      },
    }),
    {
      name: 'auth-storage',
      getStorage: () => localStorage,
    }
  )
);