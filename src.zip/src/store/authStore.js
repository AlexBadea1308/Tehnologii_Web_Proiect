import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { useCartStore } from "./cart"; 

export const useAuthStore = create(
  persist(
    (set) => ({
      user: null,
      token: null,
      isAuthenticated: false,
      
      // Login user
      login: (userData, token) => {
        set({ 
          user: userData, 
          token: token, 
          isAuthenticated: true 
        });
      },
      
      // Logout user
      logout: () => {
        
        set({ 
          user: null, 
          token: null, 
          isAuthenticated: false 
        });
      },
      
      // Update user data
      updateUser: (userData) => {
        set({ 
          user: { ...userData } 
        });
      },
    }),
    {
      name: 'auth-storage',
      getStorage: () => localStorage,
    }
  )
);