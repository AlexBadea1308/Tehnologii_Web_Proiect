import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  Box,
  Flex,
  VStack,
  Heading,
  Text,
  Button,
  Container,
  Image,
  FormControl,
  FormLabel,
  Input,
  useColorModeValue,
  Center,
  Avatar,
  useToast
} from '@chakra-ui/react';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import logo from '../../public/images/logo.png';

const EditProfilePage = () => {
  const [userData, setUserData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const toast = useToast();

  const gradient = "linear-gradient(135deg, #e62b33 0%, #8b3ea8 25%, #1e78bf 50%, #00a38e 75%, #f4a124 100%)";
  const bgColor = useColorModeValue('white', 'gray.800');

  useEffect(() => {
    // Obține datele utilizatorului din localStorage
    const storedUserData = localStorage.getItem('userData');
    if (storedUserData) {
      setUserData(JSON.parse(storedUserData));
    } else {
      navigate('/login');
    }
  }, [navigate]);

  const handleSaveChanges = async () => {
    setIsLoading(true);
    
    try {
      // Obține ID-ul utilizatorului din datele stocate
      const userId = userData._id;
      
      if (!userId) {
        throw new Error("User ID not found");
      }
      
      // Trimite datele actualizate către backend
      const response = await axios.put(`/api/users/${userId}`, {
        name: userData.name,
        surname: userData.surname,
        username: userData.username,
        email: userData.email
      });
      
      if (response.data.success) {
        // Actualizează localStorage cu noile date
        localStorage.setItem('userData', JSON.stringify(response.data.data));
        
        toast({
          title: "Profil actualizat",
          description: "Datele tale au fost actualizate cu succes",
          status: "success",
          duration: 5000,
          isClosable: true,
        });
        
        navigate('/account');
      } else {
        throw new Error(response.data.message || "Failed to update profile");
      }
    } catch (error) {
      console.error('Error updating profile:', error);
      const errorMessage = error.response?.data?.message || error.message || "A apărut o eroare la actualizarea profilului";
      
      toast({
        title: "Eroare",
        description: errorMessage,
        status: "error",
        duration: 5000,
        isClosable: true,
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (!userData) {
    return <Center h="100vh">Loading...</Center>;
  }

  return (
    <Container maxW="100%" p={0} h="100vh">
      {/* Logo in top left corner */}
      <Box position="absolute" top={4} left={4} sx={{ outline: 'none', userSelect: 'none' }}>
        <Image src={logo} alt="Logo" maxH="80px" />
      </Box>

      <Flex h="full" direction={{ base: 'column', md: 'row' }}>
        {/* Left side - Edit profile */}
        <Box 
          w={{ base: '100%', md: '60%' }} 
          p={8} 
          display="flex" 
          alignItems="center" 
          justifyContent="center"
          bg={bgColor}
          sx={{ outline: 'none', userSelect: 'none' }}
        >
          <Box w="full" maxW="400px">
            <Center mb={6}>
              <Heading as="h1" size="xl" textAlign="center">Edit Profile</Heading>
            </Center>
            
            <VStack spacing={4} align="flex-start">
              <Center w="full" mb={6}>
                <Avatar size="2xl" name={userData.username || "User"} src={userData.profileImage || ""} />
              </Center>
              
              <FormControl>
                <FormLabel>Name</FormLabel>
                <Input 
                  value={userData.name || ""} 
                  onChange={(e) => setUserData({ ...userData, name: e.target.value })} 
                  size="lg" 
                />
              </FormControl>

              <FormControl>
                <FormLabel>Surname</FormLabel>
                <Input 
                  value={userData.surname || ""} 
                  onChange={(e) => setUserData({ ...userData, surname: e.target.value })} 
                  size="lg" 
                />
              </FormControl>

              <FormControl>
                <FormLabel>Username</FormLabel>
                <Input 
                  value={userData.username || ""} 
                  onChange={(e) => setUserData({ ...userData, username: e.target.value })} 
                  size="lg" 
                />
              </FormControl>
              
              <FormControl>
                <FormLabel>Email</FormLabel>
                <Input 
                  value={userData.email || ""} 
                  onChange={(e) => setUserData({ ...userData, email: e.target.value })} 
                  size="lg" 
                />
              </FormControl>

              {/* Password field is disabled */}
              <FormControl>
                <FormLabel>Password</FormLabel>
                <Input value="********" isReadOnly size="lg" />
              </FormControl>
              
              <Button
                onClick={handleSaveChanges}
                size="lg"
                w="full"
                mt={4}
                bgGradient="linear-gradient(90deg, #1e78bf, #00a38e)"
                color="white"
                _hover={{ bgGradient: "linear-gradient(90deg, #1a6eb3, #008f7c)" }}
                isLoading={isLoading}
                loadingText="Se salvează..."
              >
                Save Changes
              </Button>

              {/* Forgot Password button */}
              <Button 
                as={RouterLink} 
                to="/forgot-password" 
                variant="link"
                color="teal.500"
                mt={2}
                size="sm"
              >
                Forgot Password?
              </Button>
            </VStack>
          </Box>
        </Box>
        
        {/* Right side - Banner with gradient */}
        <Box 
          w={{ base: '100%', md: '40%' }} 
          bgGradient={gradient}
          color="white"
          p={8}
          display="flex"
          alignItems="center"
          justifyContent="center"
          sx={{ outline: 'none', userSelect: 'none' }}
        >
          <VStack spacing={6} align="center" maxW="300px">
            <Heading as="h2" size="xl">Welcome Back!</Heading>
            <Text textAlign="center">
              {`${userData.username || "User"}, update your profile information here.`}
            </Text>
          </VStack>
        </Box>
      </Flex>
    </Container>
  );
};

export default EditProfilePage;