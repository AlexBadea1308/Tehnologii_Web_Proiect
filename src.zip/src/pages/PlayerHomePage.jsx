import React from 'react';

const PlayerHomePage = () => {
    return (
        <div>
            <h1>Welcome to the Player Home Page</h1>
            <p>This is the default home page for players.</p>
        </div>
    );
};

export default PlayerHomePage;