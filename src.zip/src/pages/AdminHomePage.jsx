import React from 'react';

const AdminHomePage = () => {
    return (
        <div>
            <h1>Welcome to the Admin Home Page</h1>
            <p>This is the default page for the admin section.</p>
        </div>
    );
};

export default AdminHomePage;