import React, { useEffect, useState } from 'react';
import {
  Container,
  Box,
  Heading,
  Text,
  VStack,
  HStack,
  Button,
  useColorModeValue,
  Spinner,
  Badge,
  Image,
  Flex,
  Alert,
  AlertIcon,
} from '@chakra-ui/react';
import NavigationBar from '../components/ui/NavigatorBarFun';
import { useAuthStore } from '../store/authStore';
import { useOrderStore } from '../store/order';
import axios from 'axios';

const OrdersHistoryPage = () => {
  const { user, isAuthenticated } = useAuthStore();
  const { orders, fetchOrders, loading: orderLoading, error: orderError } = useOrderStore();
  const bgColor = useColorModeValue('white', 'gray.800');
  const textColor = useColorModeValue('gray.800', 'white');
  const borderColor = useColorModeValue('gray.200', 'gray.700');
  const accentColor = useColorModeValue('blue.500', 'blue.300');

  const [currentPage, setCurrentPage] = useState(1);
  const ordersPerPage = 2; // Maxim 2 comenzi pe pagină

  // State pentru a stoca detaliile produselor/ticketelor
  const [itemDetails, setItemDetails] = useState({});

  useEffect(() => {
    if (isAuthenticated && user?._id) {
      fetchOrders(user._id);
    }
  }, [isAuthenticated, user?._id, fetchOrders]);

  useEffect(() => {
    const fetchItemDetails = async () => {
      const details = {};

      for (const order of orders) {
        for (const item of order.items) {
          if (!details[item.productId]) {
            try {
              if (item.productType === 'product') {
                const productResponse = await axios.get(`api/products/${item.productId}`);
                details[item.productId] = {
                  name: productResponse.data.data.name,
                  imageUrl: productResponse.data.data.image || 'https://via.placeholder.com/100?text=No+Product+Image',
                };
              } else if (item.productType === 'ticket') {
                const ticketResponse = await axios.get(`api/tickets/${item.productId}`);
                const matchData = ticketResponse.data.data.matchId;
                if (!matchData) {
                  throw new Error('Invalid match data in ticket');
                }
                details[item.productId] = {
                  name: `${matchData.teams?.[0] || 'Unknown Team'} vs ${matchData.teams?.[1] || 'Unknown Team'}`,
                  category: ticketResponse.data.data.seatCategory || 'General',
                  imageUrl: matchData.image || 'https://via.placeholder.com/100?text=No+Match+Image',
                };
              }
            } catch (error) {
              console.error(`Error fetching details for item ${item.productId}:`, error.response || error);
              details[item.productId] = {
                name: item.productType === 'product' ? 'Unnamed Product' : 'Unnamed Ticket',
                category: item.productType === 'ticket' ? 'General' : undefined,
                imageUrl: 'https://via.placeholder.com/100?text=Image+Error',
              };
            }
          }
        }
      }

      console.log('Final item details:', details);
      setItemDetails(details);
    };

    if (orders.length > 0) {
      fetchItemDetails();
    }
  }, [orders]);

  if (!isAuthenticated) {
    return (
      <Container maxW="container.md" py={8}>
        <Text color="red.500">Please log in to view your order history.</Text>
      </Container>
    );
  }

  if (orderLoading) {
    return (
      <Flex justify="center" align="center" height="100vh">
        <Spinner size="xl" color={accentColor} />
      </Flex>
    );
  }

  if (orderError) {
    return (
      <Container maxW="container.lg" centerContent>
        <Alert status="error" mt={10}>
          <AlertIcon />
          {orderError}
        </Alert>
      </Container>
    );
  }

  // Paginare
  const totalPages = Math.ceil(orders.length / ordersPerPage);
  const currentOrders = orders.slice(
    (currentPage - 1) * ordersPerPage,
    currentPage * ordersPerPage
  );

  return (
    <>
      <NavigationBar />
      <Container maxW="container.lg" py={8} sx={{ outline: 'none', userSelect: 'none' }}>
        <Box
          bgGradient="linear-gradient(0deg, rgba(34,193,195,1) 0%, rgba(25,72,129,0.3253676470588235) 100%)"
          borderRadius="2xl"
          p={12}
          mb={8}
          boxShadow="2xl"
          transition="all 0.5s"
          _hover={{ boxShadow: '3xl', transform: 'scale(1.02)' }}
          position="relative"
          overflow="hidden"
        >
          <Heading
            as="h1"
            size="2xl"
            mb={6}
            color="white"
            textAlign="center"
            fontWeight="extrabold"
            textShadow="1px 1px 2px rgba(0, 0, 0, 0.5)"
          >
            Order History
          </Heading>
          <Text
            color="white"
            fontSize="lg"
            textAlign="center"
            mb={8}
            fontStyle="italic"
          >
            View your past orders with Golazo FC!
          </Text>
        </Box>

        {orders.length === 0 ? (
          <Box
            bg={bgColor}
            borderRadius="md"
            borderWidth="1px"
            borderColor={borderColor}
            p={6}
            textAlign="center"
          >
            <Text fontSize="lg" color={textColor}>
              No orders found in your history.
            </Text>
          </Box>
        ) : (
          <VStack spacing={6} align="stretch">
            {currentOrders.map((order) => (
              <Box
                key={order._id}
                bg="linear-gradient(180deg, #1a2a3a, #2c3e50)" // Dark background similar to your design
                borderRadius="lg"
                borderWidth="2px"
                borderColor="rgba(255, 255, 255, 0.1)"
                p={6}
                boxShadow="lg"
                transition="all 0.3s"
                _hover={{ boxShadow: 'xl', transform: 'translateY(-4px)' }}
                color="white"
              >
                <HStack justify="space-between" align="center" mb={4}>
                  <Text fontWeight="bold" fontSize="xl">
                    Order #{order._id.slice(-6)}
                  </Text>
                  <Badge
                    colorScheme={
                      order.status === 'completed' ? 'green' :
                      order.status === 'pending' ? 'yellow' :
                      order.status === 'processing' ? 'blue' :
                      'red'
                    }
                    fontSize="md"
                    px={4}
                    py={2}
                    bg="rgba(255, 255, 255, 0.1)"
                    border="1px solid rgba(255, 255, 255, 0.2)"
                  >
                    {order.status}
                  </Badge>
                </HStack>
                <Text fontSize="md" mb={2} opacity={0.8}>
                  Order Date: {new Date(order.orderDate).toLocaleDateString('en-GB', {
                    day: '2-digit',
                    month: 'long',
                    year: 'numeric',
                  })}
                </Text>
                <Text fontWeight="medium" fontSize="lg" mb={2}>
                  Total: ${order.totalPrice.toFixed(2)}
                </Text>
                <Text fontSize="md" mb={1} opacity={0.8}>
                  Payment Method: {order.paymentMethod}
                </Text>
                <Text fontSize="md" mb={1} opacity={0.8}>
                  Shipping Method: {order.shippingMethod}
                </Text>
                <Text fontSize="md" mb={4} opacity={0.8}>
                  Shipping Address: {order.shippingAddress.street}, {order.shippingAddress.city}, {order.shippingAddress.postalCode}, {order.shippingAddress.country}
                </Text>

                {/* Lista de produse/tickete din comandă */}
                <Box mt={4}>
                  <Heading as="h3" size="md" mb={4}>
                    Order Items
                  </Heading>
                  <VStack spacing={4} align="stretch">
                    {order.items.map((item, index) => {
                      const detail = itemDetails[item.productId] || {};
                      return (
                        <HStack
                          key={index}
                          bgGradient="linear-gradient(180deg, rgba(0, 191, 255, 0.8) 0%, rgba(0, 51, 102, 0.8) 100%)"
                          borderRadius="md"
                          p={4}
                          boxShadow="0 4px 6px rgba(0, 0, 0, 0.1)"
                          transition="all 0.2s"
                          _hover={{ boxShadow: '0 6px 8px rgba(0, 0, 0, 0.2)', transform: 'translateY(-2px)' }}
                          color="white"
                          border="1px solid rgba(255, 255, 255, 0.1)"
                        >
                          <Image
                            src={detail.imageUrl || 'https://via.placeholder.com/100?text=Image+Error'}
                            alt={detail.name || (item.productType === 'product' ? 'Product Image' : 'Ticket Image')}
                            width={item.productType === 'product' ? '200px' : '300px'} 
                            height={item.productType === 'product' ? '250px' : '180px'}
                            objectFit="cover"
                            borderRadius="md"
                            onError={(e) => {
                              console.error('Image failed to load for item:', item.productId);
                              e.target.src = 'https://via.placeholder.com/100?text=Image+Error';
                            }}
                          />
                          <VStack align="start" spacing={1} flex="1" textShadow="0 1px 1px rgba(0, 0, 0, 0.3)">
                            <Text fontWeight="bold" fontSize="md">
                              {detail.name || (item.productType === 'product' ? 'Unnamed Product' : 'Unnamed Ticket')}
                            </Text>
                            {item.productType === 'ticket' && detail.category && (
                              <Text fontSize="sm">Category: {detail.category}</Text>
                            )}
                            <Text fontSize="sm">Type: {item.productType}</Text>
                            <Text fontSize="md">Quantity: {item.quantity}</Text>
                            <Text fontSize="md">Price: ${item.price.toFixed(2)}</Text>
                          </VStack>
                        </HStack>
                      );
                    })}
                  </VStack>
                </Box>
              </Box>
            ))}
          </VStack>
        )}

        {/* Paginare */}
        {orders.length > ordersPerPage && (
          <HStack spacing={4} mt={6} justify="center">
            <Button
              isDisabled={currentPage === 1}
              onClick={() => setCurrentPage(currentPage - 1)}
              colorScheme="blue"
              variant="outline"
              borderColor="white"
              _hover={{ bg: 'rgba(255, 255, 255, 0.1)' }}
            >
              Prev
            </Button>
            <Text>Page {currentPage} of {totalPages}</Text>
            <Button
              isDisabled={currentPage === totalPages}
              onClick={() => setCurrentPage(currentPage + 1)}
              colorScheme="blue"
              variant="outline"
              borderColor="white"
              _hover={{ bg: 'rgba(255, 255, 255, 0.1)' }}
            >
              Next
            </Button>
          </HStack>
        )}
      </Container>
    </>
  );
};

export default OrdersHistoryPage;