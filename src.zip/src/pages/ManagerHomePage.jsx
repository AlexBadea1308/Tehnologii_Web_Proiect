import React from 'react';
import NavigationBarManager from '../components/ui/NavigatorBarManager';

const ManagerHomePage = () => {

  return (
    <>
    <NavigationBarManager />
    </>
  );
};

export default ManagerHomePage;