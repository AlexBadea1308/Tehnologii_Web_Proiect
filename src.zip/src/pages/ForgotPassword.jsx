import React, { useState } from 'react';
import axios from 'axios';
import {
  Box,
  Flex,
  VStack,
  Heading,
  FormControl,
  FormLabel,
  Input,
  Button,
  useToast,
  Container,
  useColorModeValue,
  Center,
} from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';
import logo from '../../public/images/logo.png';

const ForgotPasswordPage = () => {
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const toast = useToast();
  const navigate = useNavigate();

  const gradient = "linear-gradient(135deg, #e62b33 0%, #8b3ea8 25%, #1e78bf 50%, #00a38e 75%, #f4a124 100%)";
  const bgColor = useColorModeValue('white', 'gray.800');

  const handleSavePassword = async () => {
    if (newPassword !== confirmPassword) {
      toast({
        title: "Error",
        description: "Passwords do not match!",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
      return;
    }

    setIsLoading(true);

    try {
      // Get user data from localStorage (or can fetch from an API)
      const storedUserData = localStorage.getItem('userData');
      if (!storedUserData) {
        throw new Error("No user data found");
      }

      const userData = JSON.parse(storedUserData);

      const response = await axios.put(`/api/users/${userData._id}/update-password`, {
        password: newPassword,
      });

      if (response.data.success) {
        toast({
          title: "Password Updated",
          description: "Your password has been updated successfully.",
          status: "success",
          duration: 5000,
          isClosable: true,
        });
        navigate('/');
      } else {
        toast({
          title: "Error",
          description: response.data.message || "An error occurred while updating the password.",
          status: "error",
          duration: 5000,
          isClosable: true,
        });
      }
    } catch (error) {
      console.error('Error updating password:', error);
      toast({
        title: "Error",
        description: "An error occurred while processing the request.",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Container maxW="100%" p={0} h="100vh">
      <Box position="absolute" top={4} left={4} sx={{ outline: 'none', userSelect: 'none' }}>
        {/* Logo */}
        <img src={logo} alt="Logo" width="120px" />
      </Box>

      <Flex h="full" direction={{ base: 'column', md: 'row' }}>
        <Box
          w={{ base: '100%', md: '60%' }}
          p={8}
          display="flex"
          alignItems="center"
          justifyContent="center"
          bg={bgColor}
          sx={{ outline: 'none', userSelect: 'none' }}
        >
          <Box w="full" maxW="400px">
            <Center mb={6}>
              <Heading as="h1" size="xl" textAlign="center">Reset Password</Heading>
            </Center>

            <VStack spacing={4} align="flex-start">
              <FormControl>
                <FormLabel>New Password</FormLabel>
                <Input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  size="lg"
                />
              </FormControl>

              <FormControl>
                <FormLabel>Confirm Password</FormLabel>
                <Input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  size="lg"
                />
              </FormControl>

              <Button
                onClick={handleSavePassword}
                size="lg"
                w="full"
                mt={4}
                bgGradient="linear-gradient(90deg, #1e78bf, #00a38e)"
                color="white"
                _hover={{ bgGradient: "linear-gradient(90deg, #1a6eb3, #008f7c)" }}
                isLoading={isLoading}
                loadingText="Saving..."
              >
                Save Changes
              </Button>

              <Button
                onClick={() => navigate('/')}
                size="lg"
                w="full"
                mt={4}
                variant="outline"
              >
                Return to Homepage
              </Button>
            </VStack>
          </Box>
        </Box>

        <Box
          w={{ base: '100%', md: '40%' }}
          bgGradient={gradient}
          color="white"
          p={8}
          display="flex"
          alignItems="center"
          justifyContent="center"
          sx={{ outline: 'none', userSelect: 'none' }}
        >
          <VStack spacing={6} align="center" maxW="300px">
            <Heading as="h2" size="xl">Welcome Back!</Heading>
            <p>Set a new password to access your account.</p>
          </VStack>
        </Box>
      </Flex>
    </Container>
  );
};

export default ForgotPasswordPage;
