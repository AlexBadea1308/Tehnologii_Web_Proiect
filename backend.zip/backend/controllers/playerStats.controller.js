import PlayerStats from "../models/playerStats.model.js";
import mongoose from "mongoose";

export const getAllPlayerStats = async (req, res) => {
    try {
        const stats = await PlayerStats.find().populate('playerId', 'username');
        res.status(200).json({ success: true, data: stats });
    } catch (error) {
        console.error("Error to obtain statistics: ", error.message);
        res.status(500).json({ success: false, message: "Erorr from server" });
    }
};

export const getPlayerStatsById = async (req, res) => {
    const { id } = req.params;
    
    if (!mongoose.Types.ObjectId.isValid(id)) {
        return res.status(404).json({ success: false, message: "ID invalid" });
    }
    
    try {
        const stats = await PlayerStats.findById(id).populate('playerId', 'username');
        
        if (!stats) {
            return res.status(404).json({ success: false, message: "Statistics not found" });
        }
        
        res.status(200).json({ success: true, data: stats });
    } catch (error) {
        console.error("Error to find the statistics: ", error.message);
        res.status(500).json({ success: false, message: "Erorr from server" });
    }
};

export const getStatsByPlayerId = async (req, res) => {
    const { playerId } = req.params;
    
    if (!mongoose.Types.ObjectId.isValid(playerId)) {
        return res.status(404).json({ success: false, message: "ID invalid player" });
    }
    
    try {
        const stats = await PlayerStats.findOne({ playerId }).populate('playerId', 'username');
        
        if (!stats) {
            return res.status(404).json({ success: false, message: "The statistics for this player were not found" });
        }
        
        res.status(200).json({ success: true, data: stats });
    } catch (error) {
        console.error("Error found the statistics :", error.message);
        res.status(500).json({ success: false, message: "Error from server" });
    }
};

export const createPlayerStats = async (req, res) => {
    const { playerId, goals, assists, yellowCards, redCards, matchesPlayed } = req.body;

    if (!playerId) {
        return res.status(400).json({ success: false, message: "ID-ul jucătorului " });
    }

    try {
        const existingStats = await PlayerStats.findOne({ playerId });
        
        if (existingStats) {
            return res.status(400).json({ 
                success: false, 
                message: "Statisticile pentru acest jucător există deja. Folosiți metoda PUT pentru actualizare." 
            });
        }
        
        const newStats = new PlayerStats({
            playerId,
            goals: goals || 0,
            assists: assists || 0,
            yellowCards: yellowCards || 0,
            redCards: redCards || 0,
            matchesPlayed: matchesPlayed || 0
        });

        await newStats.save();
        res.status(201).json({ success: true, data: newStats });
    } catch (error) {
        console.error("Eroare la crearea statisticilor:", error.message);
        res.status(500).json({ success: false, message: "Erorr from server" });
    }
};

export const updatePlayerStats = async (req, res) => {
    const { id } = req.params;
    const updates = req.body;
    
    if (!mongoose.Types.ObjectId.isValid(id)) {
        return res.status(404).json({ success: false, message: "ID invalid" });
    }
    
    try {
        const updatedStats = await PlayerStats.findByIdAndUpdate(
            id, 
            updates, 
            { new: true, runValidators: true }
        ).populate('playerId', 'username');
        
        if (!updatedStats) {
            return res.status(404).json({ success: false, message: "Statisticile nu au fost găsite" });
        }
        
        res.status(200).json({ success: true, data: updatedStats });
    } catch (error) {
        console.error("Eroare la actualizarea statisticilor:", error.message);
        res.status(500).json({ success: false, message: "Erorr from server" });
    }
};

export const deletePlayerStats = async (req, res) => {
    const { id } = req.params;
    
    if (!mongoose.Types.ObjectId.isValid(id)) {
        return res.status(404).json({ success: false, message: "ID invalid" });
    }
    
    try {
        const deletedStats = await PlayerStats.findByIdAndDelete(id);
        
        if (!deletedStats) {
            return res.status(404).json({ success: false, message: "Statisticile nu au fost găsite" });
        }
        
        res.status(200).json({ success: true, message: "Statisticile au fost șterse cu succes" });
    } catch (error) {
        console.error("Eroare la ștergerea statisticilor:", error.message);
        res.status(500).json({ success: false, message: "Erorr from server" });
    }
};