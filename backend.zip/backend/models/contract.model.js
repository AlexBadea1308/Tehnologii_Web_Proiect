import mongoose from "mongoose";

const contractSchema = mongoose.Schema({
    playerId: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'User',
        required: true 
    },
    startDate: { 
        type: Date, 
        required: true 
    },
    endDate: { 
        type: Date, 
        required: true 
    },
    salary: { 
        type: Number, 
        required: true 
    },
    releaseClause: { 
        type: Number,
        default: 0
    }
}, 
{
    timestamps: true
});

const Contract = mongoose.model("Contract", contractSchema);

export default Contract;