import mongoose from "mongoose";

const matchSquadSchema = mongoose.Schema({
    matchId: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'Match', 
        required: true 
    },
    players: [{
        playerId: { 
            type: mongoose.Schema.Types.ObjectId, 
            ref: 'User', 
            required: true 
        },
        position: { 
            type: String, 
            required: true 
        },
        isStarter: { 
            type: Boolean, 
            default: false 
        }
    }],
    createdBy: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'User', 
        required: true 
    },
    status: { 
        type: String, 
        enum: ['draft', 'published'], 
        default: 'draft' 
    }
}, { timestamps: true });

const MatchSquad = mongoose.model("MatchSquad", matchSquadSchema);
export default MatchSquad;