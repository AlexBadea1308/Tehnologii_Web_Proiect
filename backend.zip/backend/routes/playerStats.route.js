import express from 'express';
import { 
    getAllPlayerStats,
    getPlayerStatsById,
    getStatsByPlayerId,
    createPlayerStats,
    updatePlayerStats,
    deletePlayerStats 
} from '../controllers/playerStats.controller.js';

const router = express.Router();

router.get("/", getAllPlayerStats);
router.get("/:id", getPlayerStatsById);
router.get("/:playerId", getStatsByPlayerId);
router.post("/", createPlayerStats);
router.put("/:id", updatePlayerStats);
router.delete("/:id", deletePlayerStats);

export default router;