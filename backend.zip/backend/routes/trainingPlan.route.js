import express from 'express';
import {
    createTrainingPlan,
    getAllTrainingPlans,
    getTrainingPlanById,
    updateTrainingPlan,
    deleteTrainingPlan
} from '../controllers/trainingPlan.controller.js';
import { authMiddleware, roleMiddleware } from '../middleware/auth.js';

const router = express.Router();

router.use(authMiddleware);
router.use(roleMiddleware('manager'));

router.post('/', createTrainingPlan);
router.get('/', getAllTrainingPlans);
router.get('/:id', getTrainingPlanById);
router.put('/:id', updateTrainingPlan);
router.delete('/:id', deleteTrainingPlan);

export default router;