import express from 'express';
import { 
    getAllContracts,
    getContractById,
    getContractByPlayerId,
    createContract,
    updateContract,
    deleteContract 
} from '../controllers/contract.controller.js';

const router = express.Router();

router.get("/", getAllContracts);
router.get("/:id", getContractById);
router.get("/player/:playerId", getContractByPlayerId);
router.post("/", createContract);
router.put("/:id", updateContract);
router.delete("/:id", deleteContract);

export default router;