import express from 'express';
import {
    createMatchSquad,
    getMatchSquadByMatchId,
    updateMatchSquad,
    deleteMatchSquad
} from '../controllers/squad.controller.js';
import { authMiddleware, roleMiddleware } from '../middleware/auth.js';

const router = express.Router();

router.use(authMiddleware);
router.use(roleMiddleware('manager'));

router.post('/', createMatchSquad);
router.get('/match/:matchId', getMatchSquadByMatchId);
router.put('/:id', updateMatchSquad);
router.delete('/:id', deleteMatchSquad);

export default router;