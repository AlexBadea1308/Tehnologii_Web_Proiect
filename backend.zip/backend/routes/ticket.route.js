import express from 'express';
import {
    getTickets,
    getTicketById,
    createTicket,
    updateTicket,
    deleteTicket,
    updateTicketStock,
    getTicketByTicketId
} from '../controllers/ticket.controller.js';

const router = express.Router();

router.get('/', getTickets);
router.get('/:id/:seatCategory', getTicketById);

router.post('/', createTicket);
router.put('/:id', updateTicket);
router.delete('/:id', deleteTicket);
router.post('/stock', updateTicketStock);
router.get('/:ticketId', getTicketByTicketId);

export default router;