import express from 'express';
import { createUser, 
        getUsers, 
        updateUser, 
        deleteUser,
        getPlayers,
        updatePassword
} from '../controllers/user.controller.js';

const router = express.Router();


router.get("/", getUsers);

router.post("/",createUser);

router.delete("/:id",deleteUser);

router.put("/:id",updateUser);

router.get("/players",getPlayers);

router.put("/:id/update-password",updatePassword);

export default router;